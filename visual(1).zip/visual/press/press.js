const list = document.querySelector('.list');
const settings = document.querySelector('.settings');
list.inert = true;
list.setAttribute('aria-hidden', 'true');
list.querySelectorAll('.card').forEach((card, index) => {
  card.style.setProperty('--index', index);
});

const titleElements = [...document.querySelectorAll('.intro .logo, .intro h1, .intro .subtitle')];
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
let transitioningUntil = 0;

function captureTitle() {
  return titleElements.map(element => element.getBoundingClientRect());
}

function animateTitle(before) {
  if (reducedMotion.matches) return;
  titleElements.forEach((element, index) => {
    const after = element.getBoundingClientRect();
    if (!after.width || !after.height) return;
    element.animate([
      { transform: `translate(${before[index].left - after.left}px, ${before[index].top - after.top}px) scale(${before[index].width / after.width}, ${before[index].height / after.height})` },
      { transform: 'none' },
    ], { duration: 950, easing: 'cubic-bezier(.22, 1, .36, 1)' });
  });
}

function expand() {
  if (document.body.classList.contains('is-expanded') || performance.now() < transitioningUntil) return;
  transitioningUntil = performance.now() + (reducedMotion.matches ? 0 : 950);
  const before = captureTitle();
  document.body.classList.add('is-expanded');
  animateTitle(before);
  list.inert = false;
  list.removeAttribute('aria-hidden');
  settings.hidden = false;

}

document.querySelector('.visual').addEventListener('click', expand);

function collapse() {
  if (!document.body.classList.contains('is-expanded') || performance.now() < transitioningUntil) return;
  transitioningUntil = performance.now() + (reducedMotion.matches ? 0 : 950);
  const before = captureTitle();

  document.body.classList.remove('is-expanded');
  list.inert = true;
  list.setAttribute('aria-hidden', 'true');
  settings.hidden = true;
  window.scrollTo({ top: 0, behavior: 'instant' });
  animateTitle(before);
}
window.MocaGestures.bind({ expand, collapse });
