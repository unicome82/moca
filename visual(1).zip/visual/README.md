﻿# MOCA themes

Each theme folder contains its matching HTML, SCSS, CSS and JavaScript files:

- `prism/prism.html`
- `shape/shape.html`
- `folio/folio.html`
- `retro/retro.html`
- `press/press.html`

Open an HTML file directly to preview it. Each page loads the CSS and JavaScript
from its own folder. Compile the matching SCSS after editing, using Live Sass
or an installed Sass CLI. For example, from the `visual` folder:

```sh
sass --watch --no-source-map prism/prism.scss:prism/prism.css
```

Shared reset, color/font variables and mixins remain in `scss/`.
Settings buttons are visual placeholders.


