﻿const list = document.querySelector('.list');
const intro = document.querySelector('.intro');
const settings = document.querySelector('.settings');
let transitionUntil = 0;
const titleElements = [...intro.querySelectorAll('.logo, .copy')];

function captureTitle() {
  return titleElements.map(element => element.getBoundingClientRect());
}

function animateTitle(before) {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  titleElements.forEach((element, index) => {
    const after = element.getBoundingClientRect();
    if (!after.width || !after.height) return;
    element.animate([
      { transformOrigin: 'top left', transform: `translate(${before[index].left - after.left}px, ${before[index].top - after.top}px) scale(${before[index].width / after.width}, ${before[index].height / after.height})` },
      { transformOrigin: 'top left', transform: 'none' },
    ], { duration: 950, easing: 'cubic-bezier(.22, 1, .36, 1)' });
  });
}

list.inert = true;
list.setAttribute('aria-hidden', 'true');
list.querySelectorAll('.card').forEach((card, index) => {
  card.style.setProperty('--index', index);
});

function expand() {
  if (document.body.classList.contains('is-expanded') || performance.now() < transitionUntil) return;
  transitionUntil = performance.now() + 1100;
  const cards = [...list.querySelectorAll('.card')];
  const before = cards.slice(0, 5).map(card => card.getBoundingClientRect());
  const moveFocus = document.activeElement === intro;
  const titleBefore = captureTitle();
  document.body.classList.add('is-expanded');
  animateTitle(titleBefore);
  intro.setAttribute('aria-expanded', 'true');
  intro.removeAttribute('role');
  intro.removeAttribute('tabindex');
  list.inert = false;
  list.removeAttribute('aria-hidden');
  settings.hidden = false;
  if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    cards.slice(0, 5).forEach((card, index) => {
      const after = card.getBoundingClientRect();
      const previous = before[index];
      if (!after.width || !after.height) return;
      card.animate([
        { transformOrigin: 'top left', transform: `translate(${previous.left - after.left}px, ${previous.top - after.top}px) scale(${previous.width / after.width}, ${previous.height / after.height})` },
        { transformOrigin: 'top left', transform: 'none' },
      ], { duration: 850, easing: 'cubic-bezier(.22, 1, .36, 1)' });
    });
  }
  if (moveFocus) {
    list.setAttribute('tabindex', '-1');
    list.focus({ preventScroll: true });
  }
}

function collapse() {
  if (!document.body.classList.contains('is-expanded') || performance.now() < transitionUntil) return;
  transitionUntil = performance.now() + 1100;
  const cards = [...list.querySelectorAll('.card')].slice(0, 5);
  const before = cards.map(card => card.getBoundingClientRect());
  const moveFocus = list.contains(document.activeElement);
  const titleBefore = captureTitle();
  document.body.classList.remove('is-expanded');
  window.scrollTo({ top: 0, behavior: 'instant' });
  animateTitle(titleBefore);
  intro.setAttribute('role', 'button');
  intro.setAttribute('tabindex', '0');
  intro.setAttribute('aria-expanded', 'false');
  list.inert = true;
  list.setAttribute('aria-hidden', 'true');
  settings.hidden = true;
  if (moveFocus) intro.focus({ preventScroll: true });
  if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    cards.forEach((card, index) => {
      const after = card.getBoundingClientRect();
      if (!after.width || !after.height) return;
      card.animate([
        { translate: `${before[index].left - after.left}px ${before[index].top - after.top}px`, scale: `${before[index].width / after.width} ${before[index].height / after.height}` },
        { translate: '0 0', scale: '1 1' },
      ], { duration: 850, easing: 'cubic-bezier(.22, 1, .36, 1)' });
    });
  }
}

document.querySelector('.visual').addEventListener('click', expand);
intro.addEventListener('keydown', (event) => {
  if (event.key === 'Enter' || event.key === ' ') {
    event.preventDefault();
    expand();
  }
});


window.MocaGestures.bind({ expand, collapse });
