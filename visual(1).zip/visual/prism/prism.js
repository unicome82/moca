﻿const list = document.querySelector('.list');
const poster = document.querySelector('.poster');
const trigger = document.querySelector('.trigger');
const cards = [...list.querySelectorAll('.card')];
const sampleCount = Math.min(cards.length, 5);

function shuffle(values) {
  for (let index = values.length - 1; index > 0; index--) {
    const other = Math.floor(Math.random() * (index + 1));
    [values[index], values[other]] = [values[other], values[index]];
  }
  return values;
}

// Keep the HTML order and attach each card's color.
const tones = ['blue', 'pink', 'green', 'yellow', 'purple', 'brown', 'ivory', 'muted-blue', 'gray', 'charcoal'];
cards.forEach((card, index) => {
  card.dataset.tone = tones[index % tones.length];
});

// Evenly spaced integer values; shuffle only their assignment to cards.
function evenlySpaced(min, max) {
  return shuffle(Array.from({ length: sampleCount }, (_, index) =>
    Math.round(sampleCount === 1 ? (min + max) / 2
      : min + (max - min) * index / (sampleCount - 1))));
}

const samples = {
  shift: evenlySpaced(15, 30),
  skewX: evenlySpaced(12, 26),
  skewY: evenlySpaced(-10, 10),
  rotation: evenlySpaced(-20, 20),
  scaleX: evenlySpaced(50, 100),
  scaleY: evenlySpaced(150, 250),
};
const introShapes = [
  { radius: '8%' },
  { radius: '18%' },
  { radius: '50%' },
  { radius: '50%' },
  { radius: '8% 45% 12% 40%' },
];
shuffle(introShapes);

// Set variables before the initial delayed fade-in; CSS owns the expanded state.
cards.forEach((card, index) => {
  const sample = index % sampleCount;
  const direction = index % 2 === 0 ? -1 : 1;
  // Shuffle distinct silhouettes so each intro includes large, small and round shapes.
  const shape = introShapes[index % introShapes.length];
  const variations = {
    '--shift': `${direction * samples.shift[sample]}cqw`,
    '--skew-x': `${-direction * samples.skewX[sample]}deg`,
    '--skew-y': `${samples.skewY[sample]}deg`,
    '--rotation': `${samples.rotation[sample]}deg`,
    '--scale-x': samples.scaleX[sample] / 100,
    '--scale-y': samples.scaleY[sample] / 100,
    '--radius': shape.radius,
  };
  Object.entries(variations).forEach(([name, value]) => card.style.setProperty(name, value));
});

function expand() {
  if (poster.classList.contains('is-expanded')) return;
  trigger.setAttribute('aria-expanded', 'true');
  poster.classList.add('has-entered');
  poster.classList.add('is-expanded');
  document.querySelector('.settings').hidden = false;
  // Preserve keyboard focus when the central button is activated.
  if (document.activeElement === trigger) {
    list.setAttribute('tabindex', '-1');
    list.focus({ preventScroll: true });
  }
}

function collapse() {
  if (!poster.classList.contains('is-expanded')) return;
  const moveFocus = list.contains(document.activeElement);
  poster.classList.remove('is-expanded');
  trigger.setAttribute('aria-expanded', 'false');
  document.querySelector('.settings').hidden = true;
  window.scrollTo({ top: 0, behavior: 'instant' });
  if (moveFocus) trigger.focus({ preventScroll: true });
}
document.querySelector('.visual').addEventListener('click', expand);
window.MocaGestures.bind({ root: poster, expand, collapse });
