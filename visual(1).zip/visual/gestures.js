// Shared gesture handling; each theme owns its visual transition.
window.MocaGestures = {
  bind({ root = document.body, expand, collapse }) {
    let lockedUntil = 0;
    let distance = 0;
    let lastWheelTime = 0;
    let lastDirection = 0;
    let touch = null;
    const expanded = () => root.classList.contains('is-expanded');
    const ignored = target => target instanceof Element && target.closest('input, select, textarea, [data-no-gesture]');
    let previousState = expanded();
    new MutationObserver(() => {
      if (expanded() === previousState) return;
      previousState = expanded();
      lockedUntil = performance.now() + 1100;
      distance = 0;
    }).observe(root, { attributes: true, attributeFilter: ['class'] });

    function navigate(forward) {
      if (performance.now() < lockedUntil) return;
      if (forward ? expanded() : !expanded()) return;
      lockedUntil = performance.now() + 1100;
      forward ? expand() : collapse();
    }

    window.addEventListener('wheel', event => {
      if (event.ctrlKey || ignored(event.target) || Math.abs(event.deltaX) > Math.abs(event.deltaY)) return;
      if (performance.now() < lockedUntil) { event.preventDefault(); return; }
      const forward = event.deltaY > 0;
      if (expanded() ? forward || window.scrollY > 2 : !forward) return;
      event.preventDefault();
      const now = performance.now();
      const direction = Math.sign(event.deltaY);
      if (now - lastWheelTime > 250 || direction !== lastDirection) distance = 0;
      lastWheelTime = now;
      lastDirection = direction;
      distance += Math.abs(event.deltaY) * (event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? innerHeight : 1);
      if (distance > 70) { distance = 0; navigate(forward); }
    }, { passive: false });

    window.addEventListener('touchstart', event => {
      touch = event.touches.length === 1 && !ignored(event.target)
        ? { x: event.touches[0].clientX, y: event.touches[0].clientY, atTop: window.scrollY <= 2 }
        : null;
    }, { passive: true });
    window.addEventListener('touchend', event => {
      if (touch && event.changedTouches.length) {
        const point = event.changedTouches[0];
        const dy = touch.y - point.clientY;
        if (Math.abs(dy) > 45 && Math.abs(dy) > Math.abs(touch.x - point.clientX)) {
          if (dy > 0) navigate(true);
          else if (touch.atTop && window.scrollY <= 2) navigate(false);
        }
      }
      touch = null;
    }, { passive: true });
    window.addEventListener('touchcancel', () => { touch = null; }, { passive: true });
  },
};
