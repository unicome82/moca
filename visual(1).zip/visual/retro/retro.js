const list = document.querySelector('.list');
const intro = document.querySelector('.intro');
const settings = document.querySelector('.settings');
const palettes = ['blue', 'green', 'cream'];
document.body.dataset.palette = palettes[Math.floor(Math.random() * palettes.length)];

list.inert = true;
list.setAttribute('aria-hidden', 'true');
list.querySelectorAll('.card').forEach((card, index) => {
  card.style.setProperty('--index', index);
});

let transitioningUntil = 0;
const titleParts = [...intro.querySelectorAll('.logo, .copy')];
function captureTitle() {
  return titleParts.map(element => element.getBoundingClientRect());
}
function animateTitle(before) {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  titleParts.forEach((element, index) => {
    const after = element.getBoundingClientRect();
    if (!after.width || !after.height) return;
    element.animate([
      { transformOrigin: 'top left', transform: `translate(${before[index].left - after.left}px, ${before[index].top - after.top}px) scale(${before[index].width / after.width}, ${before[index].height / after.height})` },
      { transformOrigin: 'top left', transform: 'none' },
    ], { duration: 950, easing: 'cubic-bezier(.22, 1, .36, 1)' });
  });
}

function expand() {
  if (document.body.classList.contains('is-expanded') || performance.now() < transitioningUntil) return;
  transitioningUntil = performance.now() + 1100;
  const before = captureTitle();
  const moveFocus = document.activeElement === intro;
  document.body.classList.add('is-expanded');
  animateTitle(before);
  intro.setAttribute('aria-expanded', 'true');
  intro.removeAttribute('role');
  intro.removeAttribute('tabindex');
  list.inert = false;
  list.removeAttribute('aria-hidden');
  settings.hidden = false;
  if (moveFocus) {
    list.setAttribute('tabindex', '-1');
    list.focus({ preventScroll: true });
  }
}

document.addEventListener('click', event => {
  if (event.target.closest('.settings, a, input, select, textarea')) return;
  expand();
});
intro.addEventListener('keydown', event => {
  if (event.key === 'Enter' || event.key === ' ') {
    event.preventDefault();
    expand();
  }
});

function collapse() {
  if (!document.body.classList.contains('is-expanded') || performance.now() < transitioningUntil) return;
  transitioningUntil = performance.now() + 1100;
  const before = captureTitle();
  const moveFocus = list.contains(document.activeElement);
  const bounds = list.getBoundingClientRect();
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!reducedMotion) {
    list.classList.add('is-leaving');
    list.style.top = bounds.top + 'px';
    list.style.left = bounds.left + 'px';
    list.style.width = bounds.width + 'px';
  }
  document.body.classList.remove('is-expanded');
  if (!reducedMotion) {
    const exit = list.animate([
      { opacity: 1, transform: 'translateY(0)' },
      { opacity: 0, transform: 'translateY(25vh)' },
    ], { duration: 650, easing: 'cubic-bezier(.4, 0, .2, 1)', fill: 'forwards' });
    exit.finished.then(() => {
      list.classList.remove('is-leaving');
      ['top', 'left', 'width'].forEach(property => list.style.removeProperty(property));
      exit.cancel();
    });
  }
  intro.setAttribute('aria-expanded', 'false');
  intro.setAttribute('role', 'button');
  intro.setAttribute('tabindex', '0');
  list.inert = true;
  list.setAttribute('aria-hidden', 'true');
  settings.hidden = true;
  window.scrollTo({ top: 0, behavior: 'instant' });
  animateTitle(before);
  if (moveFocus) intro.focus({ preventScroll: true });
}
window.MocaGestures.bind({ expand, collapse });
