const list = document.querySelector('.list');
const intro = document.querySelector('.intro');
const settings = document.querySelector('.settings');
let transitionUntil = 0;

list.inert = true;
list.setAttribute('aria-hidden', 'true');
list.querySelectorAll('.card').forEach((card, index) => {
  card.style.setProperty('--index', index);
});

function expand() {
  if (document.body.classList.contains('is-expanded') || performance.now() < transitionUntil) return;
  transitionUntil = performance.now() + 1100;
  const moveFocus = document.activeElement === intro;
  const shapes = document.querySelector('.shapes');
  document.querySelector('.poster').style.setProperty('--shape-height', `${shapes.getBoundingClientRect().height}px`);
  document.body.classList.add('is-expanded');
  intro.setAttribute('aria-expanded', 'true');
  intro.removeAttribute('role');
  intro.removeAttribute('tabindex');
  list.inert = false;
  list.removeAttribute('aria-hidden');
  settings.hidden = false;
  if (moveFocus) {
    list.setAttribute('tabindex', '-1');
    list.focus({ preventScroll: true });
  }
}

function collapse() {
  if (!document.body.classList.contains('is-expanded') || performance.now() < transitionUntil) return;
  transitionUntil = performance.now() + 1100;
  const moveFocus = list.contains(document.activeElement);
  document.body.classList.remove('is-expanded');
  intro.setAttribute('aria-expanded', 'false');
  intro.setAttribute('role', 'button');
  intro.setAttribute('tabindex', '0');
  list.inert = true;
  list.setAttribute('aria-hidden', 'true');
  settings.hidden = true;
  window.scrollTo({ top: 0, behavior: 'instant' });
  if (moveFocus) intro.focus({ preventScroll: true });
}

intro.addEventListener('click', expand);
intro.addEventListener('keydown', event => {
  if (event.key === 'Enter' || event.key === ' ') {
    event.preventDefault();
    expand();
  }
});

// Keep the slide distance aligned with responsive shape sizing.
const shapeObserver = new ResizeObserver(() => {
  if (!document.body.classList.contains('is-expanded')) return;
  document.querySelector('.poster').style.setProperty('--shape-height',
    `${document.querySelector('.shapes').getBoundingClientRect().height}px`);
});
shapeObserver.observe(document.querySelector('.shapes'));

window.MocaGestures.bind({ expand, collapse });
